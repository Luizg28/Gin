
package projeto;

import java.sql.SQLException;
import javax.swing.JOptionPane;
import projeto.Aluno;
import projeto.Professor;

/**
 *
 * @author Frank
 */
public class EntradaDeDados {

    Dao dao = new Dao();

    public void entradaPessoa(String opcao) throws SQLException {
        String nome = JOptionPane.showInputDialog("Nome: ");
        String sexo = JOptionPane.showInputDialog("Sexo: ");
        long cpf = Long.parseLong(JOptionPane.showInputDialog("CPF: "));
        int idade = Integer.parseInt(JOptionPane.showInputDialog("Idade: "));
        if (opcao.equals("1")) {
            Aluno aluno = new Aluno(nome, sexo, cpf, idade);
            aluno.setRa(Integer.parseInt(JOptionPane.showInputDialog("RA: ")));
            dao.salvarAlunoNoBD(aluno);
        } else {
            Professor professor = new Professor(nome, sexo, cpf, idade);
            professor.setSiape(Long.parseLong(JOptionPane.showInputDialog("SIAPE: ")));
            dao.salvarProfessorNoBD(professor);
        }
    }
    
    public void exibirTodos(String opcao) throws SQLException{
        if (opcao.equals("2")){
            opcao = "1- Exibir todos\n2 - Exibir por nome ";
            String opt = JOptionPane.showInputDialog(opcao);
            if (opt.equals("1")){
                 dao.exibirAlunoBD();
            }
            else{
                String nome = JOptionPane.showInputDialog("Nome: ");
                Aluno aluno = new Aluno();
                aluno.setNome(nome);
                dao.buscarAlunoNoBD(aluno);
            }
        }
        else{
            opcao = "1- Exibir todos\n2 - Exibir por nome ";
            String opt = JOptionPane.showInputDialog(opcao);
            if (opt.equals("1")){
                 dao.exibirProfessorBD();
            }
            else{
                String nome = JOptionPane.showInputDialog("Nome: ");
                Professor professor = new Professor();
                professor.setNome(nome);
                dao.buscarProfessorNoBD(professor);
            }
        }
        
    }
    
    public void remover(String opcao) throws SQLException{
        if (opcao.equals("3")){
            long cpf=Long.parseLong(JOptionPane.showInputDialog("CPF: "));
            Aluno aluno = new Aluno();
            aluno.setCpf(cpf);
            dao.excluirAlunoNoBD(aluno);
        }
        else{
            long cpf = Long.parseLong(JOptionPane.showInputDialog("CPF: "));
            Professor professor = new Professor();
            professor.setCpf(cpf);
            dao.excluirProfessorNoBD(professor);
        }
    }
    
    public void alterar(String opcao) throws SQLException{
        
    }
}