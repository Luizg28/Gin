
package projeto;

import java.sql.SQLException;
import javax.swing.JOptionPane;
import projeto.Aluno;
import projeto.Professor;

/**
 *
 * @author Frank
 */
public class EntradaDeDados {

    Dao dao = new Dao();

    public void entradaPessoa(String opcao) throws SQLException {
        String nome = JOptionPane.showInputDialog("Nome: ");
        String sexo = JOptionPane.showInputDialog("Sexo: ");
        long cpf = Long.parseLong(JOptionPane.showInputDialog("CPF: "));
        int idade = Integer.parseInt(JOptionPane.showInputDialog("Idade: "));
        if (opcao.equals("1")) {
            Aluno aluno = new Aluno(nome, sexo, cpf, idade);
            aluno.setRa(Integer.parseInt(JOptionPane.showInputDialog("RA: ")));
            dao.salvarAlunoNoBD(aluno);
        } else {
            Professor professor = new Professor(nome, sexo, cpf, idade);
            professor.setSiape(Long.parseLong(JOptionPane.showInputDialog("SIAPE: ")));
            dao.salvarProfessorNoBD(professor);
        }
    }
    
    public void exibirTodos(String opcao) throws SQLException{
        if (opcao.equals("2")){
            dao.exibirAlunoBD();
        }
        else{
            dao.exibirProfessorBD();
        }
        
    }
    
    public void removerAluno(String opcao) throws SQLException{
        long cpf = Long.parseLong(JOptionPane.showInputDialog("CPF: "));
        Aluno aluno = new Aluno();
        aluno.setCpf(cpf);
        dao.excluirAlunoNoBD(aluno);
    }
    
    
}