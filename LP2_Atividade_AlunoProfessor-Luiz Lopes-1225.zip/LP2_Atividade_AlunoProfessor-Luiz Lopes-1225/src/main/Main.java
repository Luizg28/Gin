
package main;

import dao.AlunoDAO;
import dao.AreaDAO;
import dao.ProfessorDAO;
import dao.CursoDAO;
import entradasdedados.AlunoEntradaDeDados;
import entradasdedados.AreaEntradaDeDados;
import entradasdedados.ProfessorEntradaDeDados;
import entradasdedados.CursoEntradaDeDados;
import modelo.AlunoModel;
import modelo.AreaModel;
import modelo.ProfessorModel;
import modelo.CursoModel;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Main {


    public static void main(String[] args) throws SQLException {
        AlunoEntradaDeDados entradaAluno = new AlunoEntradaDeDados();
        ProfessorEntradaDeDados entradaProfessor = new ProfessorEntradaDeDados();
        AreaEntradaDeDados entradaArea = new AreaEntradaDeDados();
        CursoEntradaDeDados entradaCurso = new CursoEntradaDeDados();
        AlunoDAO daoAluno = new AlunoDAO();
        AreaDAO daoArea = new AreaDAO();
        ProfessorDAO daoProfessor = new ProfessorDAO();
        CursoDAO daoCurso = new CursoDAO();
        AlunoModel alunoModel = new AlunoModel();
        ProfessorModel professorModel = new ProfessorModel();
        AreaModel areaModel = new AreaModel();
        CursoModel cursoModel = new CursoModel();
        
        String menu = "0- Sair\n1 - Aluno\n2 - Professor\n3 - Area\n4 - Curso";
        String menuAluno = "0- Sair\n1- Voltar\n2 - Salvar\n3 - Exibir Todos\n4 - Exibir Por Ra\n5 - Editar\n6 - Remover";
        String menuProfessor = "0- Sair\n1- Voltar\n2 - Salvar\n3 - Exibir Todos\n4 - Exibir Por Siape\n5 - Editar\n6 - Remover";
        String menuArea = "0- Sair\n1- Voltar\n2 - Salvar\n3 - Exibir Todos\n4 - Exibir Por ID\n5 - Editar\n6 - Remover";
        String menuCurso = "0- Sair\n1- Voltar\n2 - Salvar\n3 - Exibir Todos\n4 - Exibir Por ID\n5 - Editar\n6 - Remover\n7 - Relacionar Aluno";

        String opt = "";
        do {
            opt = JOptionPane.showInputDialog(menu);
            switch (opt) {
                case "0":
                    break;
                case "1":
                    opt = JOptionPane.showInputDialog(menuAluno);
                    switch (opt) {
                        case "0":
                            break;
                        case "1":
                            break;
                        case "2":
                            daoAluno.salvarNoBD(entradaAluno.entradaAluno());
                            break;
                        case "3":
                            List<AlunoModel> listaDeAlunos = daoAluno.buscarTodos();
                            if(listaDeAlunos.isEmpty()){
                                JOptionPane.showMessageDialog(null, "Não foi encontrado nenhum aluno.");
                            }else{
                                for (AlunoModel aluno : listaDeAlunos) {
                                    JOptionPane.showMessageDialog(null, "Nome do Aluno: " 
                                            + aluno.getNome() + "\nIdade do Aluno: " 
                                            + aluno.getIdade()+ "\nSexo do Aluno: " 
                                            + aluno.getSexo() + "\nCPF do Aluno: " 
                                            + aluno.getCpf() + "\nRA do Aluno: " 
                                            + aluno.getRa());
                                }
                            }
                            break;
                        case "4":
                            List<AlunoModel> alunobus = daoAluno.buscarPorRa(entradaAluno.informarRa("Buscar"));
                            if(areaModel == null){
                                JOptionPane.showMessageDialog(null, "Não foi encontrado nenhum aluno com a RA informado");
                            }else{
                                for (AlunoModel alunora : alunobus) {
                                JOptionPane.showMessageDialog(null, "Nome do Aluno: " 
                                        + alunora.getNome() + "\nIdade do Aluno: " 
                                        + alunora.getIdade()+ "\nSexo do Aluno: " 
                                        + alunora.getSexo() + "\nCPF do Aluno: " 
                                        + alunora.getCpf() + "\nRA do Aluno: " 
                                        + alunora.getRa());
                            }
                            }
                            break;
                        case "5":
                            alunoModel = daoAluno.buscarPorId(entradaAluno.informarId("Buscar"));
                            if(alunoModel == null){
                                JOptionPane.showMessageDialog(null, "Não foi encontrado aluno com o ID informado");
                            }else{
                                daoAluno.salvarNoBD(entradaAluno.novaEntradaAluno(alunoModel));
                            }
                            break;
                        case "6":
                            alunoModel = daoAluno.buscarPorId(entradaAluno.informarId("Buscar"));
                            if(alunoModel == null){
                                JOptionPane.showMessageDialog(null, "Não foi encontrado aluno com o ID informado");
                            }else{
                                daoAluno.removerDoBD(alunoModel);
                            }
                            break;
                        default:
                            JOptionPane.showMessageDialog(null, "Opção inválida");
                    }
                    break;
                   case "2":
                    opt = JOptionPane.showInputDialog(menuProfessor);
                    switch (opt) {
                        case "0":
                            break;
                        case "1":
                            break;
                        case "2":
                            daoProfessor.salvarNoBD(entradaProfessor.entradaProfessor());
                            break;
                        case "3":
                            List<ProfessorModel> listaDeProfessores = daoProfessor.buscarTodos();
                            if(listaDeProfessores.isEmpty()){
                                JOptionPane.showMessageDialog(null, "Não foi encontrado nenhum professor.");
                            }else{
                                for (ProfessorModel professor : listaDeProfessores) {
                                    JOptionPane.showMessageDialog(null, "Nome do Professor: " 
                                            + professor.getNome() + "\nIdade do Professor: " 
                                            + professor.getIdade()+ "\nSexo do Professor: " 
                                            + professor.getSexo() + "\nCPF do Professor: " 
                                            + professor.getCpf() + "\nSiape do Professor: " 
                                            + professor.getSiape() + "\nArea do Professor: " 
                                            + professor.getArea().getDescricao());
                                }
                             }
                            break;
                        case "4":
                            List<ProfessorModel> professorbus = daoProfessor.buscarPorSiape(entradaProfessor.informarSiape("Buscar"));
                            if(areaModel == null){
                                JOptionPane.showMessageDialog(null, "Não foi encontrado professor com a Siape informado");
                            }else{
                                for (ProfessorModel professorSiape : professorbus) {
                                JOptionPane.showMessageDialog(null, "Nome do Professor: " 
                                        + professorSiape.getNome() + "\nIdade do Professor: " 
                                        + professorSiape.getIdade()+ "\nSexo do Professor: " 
                                        + professorSiape.getSexo() + "\nCPF do Professor: " 
                                        + professorSiape.getCpf() + "\nSiape do Professor: " 
                                        + professorSiape.getSiape() + "\nArea do Professor: " 
                                        + professorSiape.getArea().getDescricao());
                            }
                            }
                            break;
                        case "5":
                            professorModel = daoProfessor.buscarPorId(entradaProfessor.informarId("Buscar"));
                            if(professorModel == null){
                                JOptionPane.showMessageDialog(null, "Não foi encontrado professor com o ID informado");
                            }else{
                                daoProfessor.salvarNoBD(entradaProfessor.novaEntradaProfessor(professorModel));
                            }
                            break;
                        case "6":
                            professorModel = daoProfessor.buscarPorId(entradaProfessor.informarId("Buscar"));
                            if(professorModel == null){
                                JOptionPane.showMessageDialog(null, "Não foi encontrado professor com o ID informado");
                            }else{
                                daoProfessor.removerDoBD(professorModel);
                            }
                            break;
                        default:
                            JOptionPane.showMessageDialog(null, "Opção inválida");
                    }
                    break;
                case "3":
                    opt = JOptionPane.showInputDialog(menuArea);
                    switch (opt) {
                        case "0":
                            break;
                        case "1":
                            break;
                        case "2":
                            daoArea.salvarOuAtualizar(entradaArea.entradaArea());
                            break;
                        case "3":
                            List<AreaModel> listaDeArea = daoArea.buscarTodos();
                            if(listaDeArea.isEmpty()){
                                JOptionPane.showMessageDialog(null, "Não foi encontrado nenhuma area.");
                            }else{
                               for (AreaModel area : listaDeArea) {
                                    JOptionPane.showMessageDialog(null, "Descrição da Area: " + area.getDescricao());
                                } 
                            }
                            break;
                        case "4":
                            areaModel = daoArea.buscarPorId(entradaArea.informarID("Buscar"));
                            if(areaModel == null){
                                JOptionPane.showMessageDialog(null, "Não foi encontrada area com o ID informado");
                            }else{
                                JOptionPane.showMessageDialog(null, "Descrição da Area: " + areaModel.getDescricao());
                            }
                            break;
                        case "5":
                           areaModel = daoArea.buscarPorId(entradaArea.informarID("Editar"));
                            if(areaModel == null){
                                JOptionPane.showMessageDialog(null, "Não foi encontrada area com o ID informado");
                            }else{
                                daoArea.salvarOuAtualizar(entradaArea.novaEntradaArea(areaModel));
                            }
                            break;
                        case "6":
                            areaModel = daoArea.buscarPorId(entradaArea.informarID("Remover"));
                            if(areaModel == null){
                                JOptionPane.showMessageDialog(null, "Não foi encontrada area com o ID informado");
                            }else{
                                daoArea.remover(areaModel);
                            }
                            break;
                        default:
                            JOptionPane.showMessageDialog(null, "Opção inválida");
                    }
                    break;
                    case "4":
                    opt = JOptionPane.showInputDialog(menuCurso);
                    switch (opt) {
                        case "0":
                            break;
                        case "1":
                            break;
                        case "2":
                            daoCurso.salvarNoBD(entradaCurso.entradaCurso());
                            break;
                        case "3":
                            List<CursoModel> listaDeCursos = daoCurso.buscarTodos();
                            if(listaDeCursos.isEmpty()){
                                JOptionPane.showMessageDialog(null, "Não foi encontrado nenhum curso");
                            }else{
                                for (CursoModel curso : listaDeCursos) {
                                        List<AlunoModel> listaAlunos;
                                        listaAlunos = curso.getListaDeAluno();
                                        if(listaAlunos.isEmpty()){
                                            JOptionPane.showMessageDialog(null, "Titulo do Curso: " 
                                                    + curso.getTitulo() + "\nDescrição do Curso: " 
                                                    + curso.getDescricao()+ "\nLocal do Curso: " 
                                                    + curso.getLocalc() + "\nQuantidade de Vagas do Curso: " 
                                                    + curso.getQtdVagas());
                                        }else{
                                            for (AlunoModel al : listaAlunos){
                                                JOptionPane.showMessageDialog(null, "Titulo do Curso: " 
                                                    + curso.getTitulo() + "\nDescrição do Curso: " 
                                                    + curso.getDescricao()+ "\nLocal do Curso: " 
                                                    + curso.getLocalc() + "\nQuantidade de Vagas do Curso: " 
                                                    + curso.getQtdVagas() + "\nAluno: " + al.getNome());
                                            }
                                        }
                                   }
                                }
                            break;
                        case "4":
                            cursoModel = daoCurso.buscarPorId(entradaCurso.informarID("Buscar"));
                            List<AlunoModel> listaAlunosi;
                            if(cursoModel == null){
                                JOptionPane.showMessageDialog(null, "Não foi encontrado curso com o ID informado");
                            }else{
                                listaAlunosi = cursoModel.getListaDeAluno();
                                for (AlunoModel ali : listaAlunosi){
                                    JOptionPane.showMessageDialog(null, "Titulo do Curso: " 
                                        + cursoModel.getTitulo() + "\nDescrição do Curso: " 
                                        + cursoModel.getDescricao()+ "\nLocal do Curso: " 
                                        + cursoModel.getLocalc() + "\nQuantidade de Vagas do Curso: " 
                                        + cursoModel.getQtdVagas() + "\nAluno: " + ali.getNome());
                                }   
                            }
                            break;
                        case "5":
                            cursoModel = daoCurso.buscarPorId(entradaCurso.informarID("Buscar"));
                            if(cursoModel == null){
                                JOptionPane.showMessageDialog(null, "Não foi encontrado nenhum Curso com o ID informado");
                            }else{
                                daoCurso.salvarNoBD(entradaCurso.novaEntradaCurso(cursoModel));
                            }
                            break;
                        case "6":
                            cursoModel = daoCurso.buscarPorId(entradaCurso.informarID("Buscar"));
                            if(cursoModel == null){
                                JOptionPane.showMessageDialog(null, "Não foi encontrado nenhum Curso com o ID informado");
                            }else{
                                daoCurso.removerDoBD(cursoModel);
                            }
                            break;
                        case "7":
                            cursoModel = daoCurso.buscarPorId(entradaCurso.informarID("Buscar"));
                            if(cursoModel == null){
                                JOptionPane.showMessageDialog(null, "Não foi encontrado nenhum Curso com o ID informado");
                            }else{
                                cursoModel = entradaCurso.inserirAC(cursoModel);
                                daoCurso.salvarCANoBD(cursoModel);
                            }
                            break;
                        default:
                            JOptionPane.showMessageDialog(null, "Opção inválida");        
                    }
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida");
            }
        } while (!opt.equals("0"));
        daoAluno.encerrar();
        daoArea.encerrar();
		daoProfessor.encerrar();
        daoCurso.encerrar();
    }
    
}
