package entradasdedados;

import dao.AreaDAO;
import dao.CursoDAO;
import javax.swing.JOptionPane;
import modelo.AreaModel;
import modelo.CursoModel;
import modelo.ProfessorModel;


public class ProfessorEntradaDeDados {
    AreaDAO daoArea = new AreaDAO();
    AreaModel areaModelp = new AreaModel();

    public ProfessorModel entradaProfessor() {
        String nome = JOptionPane.showInputDialog("Nome: ");
        String sexo = JOptionPane.showInputDialog("Sexo: ");
        long cpf = Long.parseLong(JOptionPane.showInputDialog("CPF: "));
        int idade = Integer.parseInt(JOptionPane.showInputDialog("Idade: "));
        ProfessorModel professor = new ProfessorModel(nome, idade, cpf, sexo);
        professor.setSiape(Long.parseLong(JOptionPane.showInputDialog("Siape: ")));
        int areaProf = Integer.parseInt(JOptionPane.showInputDialog("Id Area: "));

        areaModelp = daoArea.buscarPorId(areaProf);
        if (areaModelp == null) {
            JOptionPane.showMessageDialog(null, "Não foi encontrada area com o ID informado");
            return null;
        } else {
            professor.setArea(areaModelp);
        };
        return professor;
    }

    public ProfessorModel novaEntradaProfessor(ProfessorModel professor) {
        professor.setNome(JOptionPane.showInputDialog("Novo Nome: "));
        professor.setSexo(JOptionPane.showInputDialog("Novo Sexo: "));
        professor.setCpf(Long.parseLong(JOptionPane.showInputDialog("Novo CPF: ")));
        professor.setIdade(Integer.parseInt(JOptionPane.showInputDialog("Nova Idade: ")));
        professor.setSiape(Long.parseLong(JOptionPane.showInputDialog("Nova Siape: ")));
        int areaId = Integer.parseInt(JOptionPane.showInputDialog("Id Area: "));
        areaModelp = daoArea.buscarPorId(areaId);
        if (areaModelp == null) {
            JOptionPane.showMessageDialog(null, "Não foi encontrada area com o ID informado");
            return null;
        } else {
            professor.setArea(areaModelp);
        }
        return professor;
    }

    public long informarSiape(String acao) {
        long siape = Long.parseLong(JOptionPane.showInputDialog("Entre com a Siape de quem deseja " + acao + ": "));
        return siape;
    }

    public int informarId(String acao) {
        int id = Integer.parseInt(JOptionPane.showInputDialog("Entre com o id de quem deseja " + acao + ": "));
        return id;
    }
}
