
package entradasdedados;

import dao.AlunoDAO;
import dao.AreaDAO;
import dao.CursoDAO;
import dao.ProfessorDAO;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import modelo.AlunoModel;
import modelo.AreaModel;
import modelo.CursoModel;
import modelo.ProfessorModel;

public class CursoEntradaDeDados {
    AreaDAO daoArea = new AreaDAO();
    AreaModel areaModelc = new AreaModel();
    ProfessorDAO daoProfessor = new ProfessorDAO();
    ProfessorModel professorModel = new ProfessorModel();
    CursoDAO daoCurso = new CursoDAO();
    CursoModel cursoModelc = new CursoModel();
    AlunoDAO daoAluno = new AlunoDAO();
    AlunoModel alunoModelc = new AlunoModel();
    
    public CursoModel entradaCurso(){
        CursoModel curso = new CursoModel();
        curso.setTitulo(JOptionPane.showInputDialog("Título: "));
        curso.setDescricao(JOptionPane.showInputDialog("Descrição: "));
        curso.setLocalc(JOptionPane.showInputDialog("Local: "));
        curso.setQtdVagas(JOptionPane.showInputDialog("Quantidade de Vagas: "));
        /*int areaCur = Integer.parseInt(JOptionPane.showInputDialog("Id Area: "));
        areaModelc = daoArea.buscarPorId(areaCur);
        if (areaModelc == null) {
            JOptionPane.showMessageDialog(null, "Não foi encontrada area com o ID informado");
        } else {
            curso.setArea(areaModelc);
        }*/
        int profId = Integer.parseInt(JOptionPane.showInputDialog("Id Professor: "));
        professorModel = daoProfessor.buscarPorId(profId);
        if (professorModel == null) {
            JOptionPane.showMessageDialog(null, "Não foi encontrada professor com o ID informado");
            return null;
        } else {
            curso.setProfessor(professorModel);
        }
        
        return curso;
    }

    public CursoModel novaEntradaCurso(CursoModel curso){
        curso.setTitulo(JOptionPane.showInputDialog("Novo Título: "));
        curso.setDescricao(JOptionPane.showInputDialog("Nova Descrição: "));
        curso.setLocalc(JOptionPane.showInputDialog("Novo Local: "));
        curso.setQtdVagas(JOptionPane.showInputDialog("Nova Quantidade de Vagas: "));
        int profId = Integer.parseInt(JOptionPane.showInputDialog("Id Professor: "));
        professorModel = daoProfessor.buscarPorId(profId);
        if (professorModel == null) {
            JOptionPane.showMessageDialog(null, "Não foi encontrada professor com o ID informado");
            return null;
        } else {
            curso.setProfessor(professorModel);
        }
        return curso;
    }
    
    public int informarID(String acao){
        int id = Integer.parseInt(JOptionPane.showInputDialog("Entre com o ID de quem deseja "+acao+": "));
        return id;
    }
    
    
    public CursoModel inserirAC(CursoModel curso){
        int alunoId = Integer.parseInt(JOptionPane.showInputDialog("Id Aluno: "));
            alunoModelc = daoAluno.buscarPorId(alunoId);
                if(alunoModelc == null){
                    JOptionPane.showMessageDialog(null, "Não foi encontrado nenhum Aluno com o ID informado");
                        return null;
                }else{
                    List<AlunoModel> listaAlunos = new ArrayList<AlunoModel>();
                    listaAlunos.add(alunoModelc);
                    curso.setListaDeAluno(listaAlunos);
                }
        return curso;
    }
}
