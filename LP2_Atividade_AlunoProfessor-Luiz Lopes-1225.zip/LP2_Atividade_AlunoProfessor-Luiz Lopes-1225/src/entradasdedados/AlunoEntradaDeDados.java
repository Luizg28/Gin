
package entradasdedados;

import dao.AlunoDAO;
import dao.CursoDAO;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import modelo.AlunoModel;
import modelo.CursoModel;

public class AlunoEntradaDeDados {
    CursoDAO daoCurso = new CursoDAO();
    CursoModel cursoModela = new CursoModel();

    public AlunoModel entradaAluno(){
        String nome = JOptionPane.showInputDialog("Nome: ");
        String sexo = JOptionPane.showInputDialog("Sexo: ");
        long cpf = Long.parseLong(JOptionPane.showInputDialog("CPF: "));
        int idade = Integer.parseInt(JOptionPane.showInputDialog("Idade: "));
        AlunoModel aluno = new AlunoModel(nome, idade, cpf, sexo);
        aluno.setRa(Integer.parseInt(JOptionPane.showInputDialog("RA: ")));      
        return aluno;
    }

    public AlunoModel novaEntradaAluno(AlunoModel aluno){
        aluno.setNome(JOptionPane.showInputDialog("Novo Nome: "));
        aluno.setSexo(JOptionPane.showInputDialog("Novo Sexo: "));
        aluno.setCpf(Long.parseLong(JOptionPane.showInputDialog("Novo CPF: ")));
        aluno.setIdade(Integer.parseInt(JOptionPane.showInputDialog("Nova Idade: ")));
        aluno.setRa(Integer.parseInt(JOptionPane.showInputDialog("Novo RA: ")));  
        return aluno;
    }
    
    public int informarRa(String acao){
        int ra = Integer.parseInt(JOptionPane.showInputDialog("Entre com o RA de quem deseja "+acao+": ")); 
        return ra;
    }
    
    public int informarId(String acao){
        int id = Integer.parseInt(JOptionPane.showInputDialog("Entre com o id de quem deseja "+acao+": ")); 
        return id;
    }
}
