
package modelo;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "aluno")
@PrimaryKeyJoinColumn(name = "idpessoa")
public class AlunoModel extends PessoaModel{
    private int ra;
    
    @ManyToMany(mappedBy = "listaDeAlunos")
    private List<CursoModel> listaDeCursos = new ArrayList<>();

    public List<CursoModel> getCurso() {
        return listaDeCursos;
    }

    public void setCurso(List<CursoModel> curso) {
        this.listaDeCursos = curso;
    }

    public AlunoModel(String nome, int idade, long cpf, String sexo) {
        super(nome, idade, cpf, sexo);
    }
    
    public AlunoModel(){
        
    }
        
    public int getRa() {
        return ra;
    }

    public void setRa(int ra) {
        this.ra = ra;
    }
    
    
}
