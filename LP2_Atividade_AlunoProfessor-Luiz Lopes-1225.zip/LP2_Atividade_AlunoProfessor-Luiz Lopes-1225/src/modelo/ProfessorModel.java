
package modelo;

import java.util.List;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "professor")
@PrimaryKeyJoinColumn(name = "idPessoa")
public class ProfessorModel extends PessoaModel{
    private long siape;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="idAreap", insertable=true, updatable=true)
    @Fetch(FetchMode.JOIN)
    @Cascade(CascadeType.SAVE_UPDATE)
    private AreaModel area;
   
    @OneToMany(mappedBy="professor", fetch = FetchType.LAZY)
    @Cascade(CascadeType.SAVE_UPDATE)
    private List<CursoModel> listaDeCursos;

    public ProfessorModel() {
        
    }
    
    public List<CursoModel> getListaDeCursos() {
        return listaDeCursos;
    }

    public void setListaDeProfessores(List<CursoModel> listaDeCursos) {
        this.listaDeCursos = listaDeCursos;
    }

     public ProfessorModel(String nome, int idade, long cpf, String sexo) {
        super(nome, idade, cpf, sexo);
    }

    public AreaModel getArea() {
        return area;
    }

    public void setArea(AreaModel area) {
        this.area = area;
    }
     
    public long getSiape() {
        return siape;
    }

    public void setSiape(long siape) {
        this.siape = siape;
    }
}
