
package dao;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import modelo.ProfessorModel;

public class ProfessorDAO extends Conexao{
    
    public void salvarNoBD(ProfessorModel professor){
        try {
            iniciar();
            getSessao().saveOrUpdate(professor);
            fechar();
            JOptionPane.showMessageDialog(null, "Salvo com Sucesso !");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro: " + e.getMessage());
        }
    }
    
    public List<ProfessorModel> buscarPorSiape(long siape){
        List<ProfessorModel> listaDeProfessores = new ArrayList<>();
        try {
            iniciar();
            listaDeProfessores = getSessao().createQuery("from ProfessorModel where SIAPE = " + siape + "").list();
            fechar();
            JOptionPane.showMessageDialog(null, "Encontrado com Sucesso !");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar: " + e.getMessage());
        }
        return listaDeProfessores;
    }
    
    public List<ProfessorModel> buscarTodos(){
        List<ProfessorModel> listaDeProfessores = new ArrayList<>();
        try {
            iniciar();
            listaDeProfessores = getSessao().createQuery("from ProfessorModel").list();
            fechar();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar: " + e.getMessage());
        }
        return listaDeProfessores;
    }
    
    public ProfessorModel buscarPorId(int id) {
        try {
            iniciar();
            ProfessorModel professor = (ProfessorModel) getSessao().get(ProfessorModel.class, id);
            fechar();
            return professor;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar: " + e.getMessage());
        }
        return null;
    }
    
    public void removerDoBD(ProfessorModel professor) {
        try {
            iniciar();
            getSessao().delete(professor);
            fechar();
            JOptionPane.showMessageDialog(null, "Removido com sucesso !");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao remover: " + e.getMessage());
        }
    }
}
