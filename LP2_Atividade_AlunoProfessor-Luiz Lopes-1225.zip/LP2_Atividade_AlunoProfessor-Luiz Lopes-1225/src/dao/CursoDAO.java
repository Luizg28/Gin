
package dao;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import modelo.AlunoModel;
import modelo.CursoModel;

public class CursoDAO extends Conexao{
    
    public void salvarNoBD(CursoModel curso){
        try {
            iniciar();
            getSessao().saveOrUpdate(curso);
            fechar();
            JOptionPane.showMessageDialog(null, "Salvo com Sucesso !");
        } catch (Exception e) {
           
        }
    }
    
    public List<CursoModel> buscarPorid(int id){
        List<CursoModel> listaDeCursos = new ArrayList<>();
        try {
            iniciar();
            listaDeCursos = getSessao().createQuery("from CursoModel where id = " + id + "").list();
            fechar();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar: " + e.getMessage());
        }
        return listaDeCursos;
    }
    
    public List<CursoModel> buscarTodos(){
        List<CursoModel> listaDeCursos = new ArrayList<>();
        try {
            iniciar();
            listaDeCursos = getSessao().createQuery("from CursoModel").list();
            fechar();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar: " + e.getMessage());
        }
        return listaDeCursos;
    }
    
    public CursoModel buscarPorId(int id) {
        try {
            iniciar();
            CursoModel curso = (CursoModel) getSessao().get(CursoModel.class, id);
            fechar();
            return curso;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar: " + e.getMessage());
        }
        return null;
    }
    
    public void removerDoBD(CursoModel curso) {
        try {
            iniciar();
            getSessao().delete(curso);
            fechar();
            JOptionPane.showMessageDialog(null, "Removido com sucesso !");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao remover: " + e.getMessage());
        }
    }
    
    public void salvarCANoBD(CursoModel curso){
        try {
            iniciar();
            getSessao().saveOrUpdate(curso);
            fechar();
            JOptionPane.showMessageDialog(null, "Salvo com Sucesso !");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro: " + e.getMessage());
        }
    }
}
