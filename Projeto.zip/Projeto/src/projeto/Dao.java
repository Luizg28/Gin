
package projeto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import projeto.Aluno;
import projeto.Pessoa;
import projeto.Professor;

public class Dao {
    
    int contA=1;
    int contP=1;

    List<Pessoa> listaDePessoas = new ArrayList<>();

    public void salvar(Pessoa pessoa) {
        listaDePessoas.add(pessoa);
    }

    public void exibirTodos(String opcao) {
        String msg = "";
        if (opcao.equals("2")) {
            for (int i = 0; i < listaDePessoas.size(); i++) {
                if (listaDePessoas.get(i) instanceof Aluno) {
                    Aluno aluno = (Aluno) listaDePessoas.get(i);
                    msg += aluno.getNome() + " - RA: " + aluno.getRa() + "\n";
                }
            }
        } else {
            for (int i = 0; i < listaDePessoas.size(); i++) {
                if (listaDePessoas.get(i) instanceof Professor) {
                    Professor professor = (Professor) listaDePessoas.get(i);
                    msg = professor.getNome() + " - SIAPE: " + professor.getSiape();
                }
            }
        }
        JOptionPane.showMessageDialog(null, msg);
    }

    public void remover(long cpf, String opcao) {
        boolean removido = false;

        for (Pessoa pessoa : listaDePessoas) {
            if (pessoa.getCpf() == cpf) {
                if ((opcao.equals("3") && pessoa instanceof Aluno)
                        || (opcao.equals("6") && pessoa instanceof Professor)) {
                    listaDePessoas.remove(pessoa);
                    JOptionPane.showMessageDialog(null, pessoa.getClass().getSimpleName()
                            + " Removido com sucesso!");
                    removido = true;
                }
            }
        }

        if (!removido) {
            JOptionPane.showMessageDialog(null, "CPF não encontrado");
        }
    }
    
    public void salvarAlunoNoBD(Aluno aluno) throws SQLException{
        Connection conexao = null;
        try {
            conexao = DriverManager.getConnection("jdbc:derby://localhost:1527/Banco", "nbuser", "nbuser");
            String sql = "insert into aluno (idpessoa, nome, idade,cpf, ra,sexo) " +
                    "values(?,?,?,?,?,?)";
            PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setInt(1,contA);
            ps.setString(2, aluno.getNome());
            ps.setInt(3, aluno.getIdade());
            ps.setLong(4, aluno.getCpf());
            ps.setInt(5, aluno.getRa());
            ps.setString(6,aluno.getSexo());
            
            int retorno = ps.executeUpdate();
            if (retorno > 0) {
                JOptionPane.showMessageDialog(null, "Salvo com Sucesso !");
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        } finally{
            conexao.close();
        }
        contA++;
    }
     public void salvarProfessorNoBD(Professor professor) throws SQLException{
        Connection conexao = null;
        try {
            conexao = DriverManager.getConnection("jdbc:derby://localhost:1527/Banco", "nbuser", "nbuser");
            String sql = "insert into professor (idpessoa, nome,sexo,idade,cpf,siape) " +
                    "values(?,?,?,?,?,?)";
            PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setInt(1,contP);
            ps.setString(2, professor.getNome());
            ps.setString(3,professor.getSexo());
            ps.setInt(4, professor.getIdade());
            ps.setLong(5, professor.getCpf());
            ps.setLong(6, professor.getSiape());
            
            int retorno = ps.executeUpdate();
            if (retorno > 0) {
                JOptionPane.showMessageDialog(null, "Salvo com Sucesso !");
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        } finally{
            conexao.close();
        }
        contP++;
    }
    public void exibirAlunoBD() throws SQLException{
        Connection conexao = null;
        try {
            conexao = DriverManager.getConnection("jdbc:derby://localhost:1527/Banco", "nbuser", "nbuser");
            String sql = "select * from aluno";
            PreparedStatement ps = conexao.prepareStatement(sql);
            ResultSet listaAluno = ps.executeQuery();
            while(listaAluno.next()){
                JOptionPane.showMessageDialog(null, "Nome: "+listaAluno.getString("nome") 
                        +"\n"+ "Sexo: "+listaAluno.getString("sexo")
                        +"\n"+"CPF: "+listaAluno.getString("cpf")
                        +"\n"+"Idade: "+listaAluno.getString("idade")
                        +"\n"+"RA: "+listaAluno.getString("ra"));
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        } finally{
            conexao.close();
        }
    }
    public void exibirProfessorBD() throws SQLException{
        Connection conexao = null;
        try {
            conexao = DriverManager.getConnection("jdbc:derby://localhost:1527/Banco", "nbuser", "nbuser");
            String sql = "select * from professor";
            PreparedStatement ps = conexao.prepareStatement(sql);
            ResultSet listaProfessor = ps.executeQuery();
            while(listaProfessor.next()){
                JOptionPane.showMessageDialog(null, "Nome: "+listaProfessor.getString("nome") 
                        +"\n"+ "Sexo: "+listaProfessor.getString("sexo")
                        +"\n"+"CPF: "+listaProfessor.getString("cpf")
                        +"\n"+"Idade: "+listaProfessor.getString("idade")
                        +"\n"+"Siape: "+listaProfessor.getString("siape"));
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        } finally{
            conexao.close();
        }
    }
}