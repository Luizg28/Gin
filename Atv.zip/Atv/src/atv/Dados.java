package atv;

public class Dados {
    private String nome;
    private int idade;
    private int cpf;
    private int ra;
    private float siape;
    private String sexo;
    
    public String getNome(){
        return nome;
    }
    public void setNome(String nome){
        this.nome = nome;
    }
    public int getIdade(){
        return idade;
    }
    public void setIdade(int idade){
        this.idade = idade;
    }
    public int getCpf(){
        return cpf;
    }
    public void setCpf(int cpf){
        this.cpf = cpf;
    }
    public int getRa(){
        return ra;
    }
    public void setRa(int ra){
        this.ra = ra;
    }
    public float getSiape(){
        return siape;
    }
    public void setSiape(float siape){
        this.siape = siape;
    }
    public String getSexo(){
        return sexo;
    }
    public void setSexo(String sexo){
        this.sexo = sexo;
    }
}
