package atv;
import java.util.Scanner;

public class Main {
    public static void main(String args){

        
        Scanner sc = new Scanner(System.in);
	Dados[] dado = new Dados[1];
        
        System.out.println("Nome: ");
        dado[1].setNome(sc.nextLine());
        sc.nextLine();
        System.out.println("Idade: ");
        dado[1].setIdade(sc.nextInt());
        System.out.println("Cpf: ");
        dado[1].setCpf(sc.nextInt());
        System.out.println("Ra");
        dado[1].setRa(sc.nextInt());
        System.out.println("Siape");
        dado[1].setSiape(sc.nextFloat());
        sc.nextLine();
        System.out.println("Sexo: ");
        dado[1].setNome(sc.nextLine());
        
    }
}
