import java.util.Scanner;

public class TestaArrayAluno {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		Aluno[] alunos = new Aluno[1];
		
		for (int i=0; i<alunos.length; i++) {
			
			alunos[i] = new Aluno();
			System.out.println("RA do aluno: ");
			alunos[i].setRa(sc.nextInt());
			sc.nextLine();
			System.out.println("Nome do Aluno: ");
			alunos[i].setNome(sc.nextLine());
			System.out.println("CPF do aluno: ");
			alunos[i].setCpf(sc.nextLine());
			
		}
		
		for (Aluno x : alunos) {
			
			System.out.println(x.getRa());
			System.out.println(x.getNome());
			System.out.println(x.getCpf());
			
		}
		
		

	}

}
